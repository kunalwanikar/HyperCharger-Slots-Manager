package com.example.hyperchargerslotsmanager

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hyperchargerslotsmanager.constants.Constant.Companion.TEST_LAT
import com.example.hyperchargerslotsmanager.constants.Constant.Companion.TEST_LONG
import com.example.hyperchargerslotsmanager.utils.PermissionUtils.PermissionDeniedDialog.Companion.newInstance
import com.example.hyperchargerslotsmanager.utils.PermissionUtils.isPermissionGranted
import com.example.hyperchargerslotsmanager.utils.PermissionUtils.requestPermission
import com.example.hyperchargerslotsmanager.adapters.HyperChargerAdapter
import com.example.hyperchargerslotsmanager.databinding.ActivityMapsBinding
import com.example.hyperchargerslotsmanager.helpers.BookSlotHelper
import com.example.hyperchargerslotsmanager.model.EvseDetails
import com.example.hyperchargerslotsmanager.model.HCFreeSlotResponse
import com.example.hyperchargerslotsmanager.services.BookSlotService
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MapsActivity : AppCompatActivity(), GoogleMap.OnMyLocationButtonClickListener,
    GoogleMap.OnMyLocationClickListener, OnMapReadyCallback,
    ActivityCompat.OnRequestPermissionsResultCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private var permissionDenied = false
    private lateinit var newRecyclerView: RecyclerView
    private lateinit var newArrayList: ArrayList<HCFreeSlotResponse>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        newRecyclerView = binding.recyclerview
        newRecyclerView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        newArrayList = arrayListOf<HCFreeSlotResponse>()
        getHCData()
    }


    private fun getHCData() {
        val bookSlotService = BookSlotHelper.getInstance().create(BookSlotService::class.java)
//        Log.d("abcd1234", "Result Start :::::::::::::::::::::::::::::::::::: Result End")

        GlobalScope.launch {
            withContext(Dispatchers.IO) {
//                Log.d("abcd1234", "Before Result :::::::::::::::::::::::::::::::::::: Result End")
//            Log.d("abcd1234", lbsService.getHCFreeSlots().body().toString())
                val result = bookSlotService.getHCFreeSlots()
//                Log.d("abcd1234", "Result ::::: ${result.code()}")
                ///  if (result != null)
                // Checking the results
//                Log.d("abcd1234", result.body().toString())
                result.body()?.let {
                    runOnUiThread {
                        markMarkers(it)
                        addInfoToHC(it)
                        onMapReady(mMap)
                    }
                }
            }
        }
    }


    private fun addInfoToHC(HCResponseList: HCFreeSlotResponse) {
        for (i in 0 until (HCResponseList.evcsDetails.size)) {
            val HCInfo =
                HCFreeSlotResponse(HCResponseList.timestamp, HCResponseList.evcsDetails)
            newArrayList.add(HCInfo)
        }
        newRecyclerView.adapter =
            HyperChargerAdapter(newArrayList, this, object : HyperChargerAdapter.BtnClickListener {
                override fun onBtnClick(currentItem: HCFreeSlotResponse, position: Int) {
//                    Toast.makeText(applicationContext, "Toast Clicked", Toast.LENGTH_SHORT).show()

                    val bottomSheetFragment: BottomSheetDialogFragment =
                        SlotFragment()
                    val bundle = Bundle()
                    bundle.putParcelable("key",currentItem)
                    bundle.putInt("position",position)
                    bottomSheetFragment.arguments = bundle
                    bottomSheetFragment.show(supportFragmentManager, bottomSheetFragment.tag)
                }

                override fun onImageClick(hcList: HCFreeSlotResponse, position: Int) {
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(hcList.evcsDetails.get(position).lat, hcList.evcsDetails.get(position).long), 15f))
                }
            }, mMap
            )
    }

    private fun markMarkers(HCResponseList: HCFreeSlotResponse) {
//        Log.d("abcd1234","timestamp -> ${HCResponseList.timestamp}")
            for (i in 0 until (HCResponseList.evcsDetails.size)) {
            val HCLocation = LatLng(
                HCResponseList.evcsDetails[i].lat,
                HCResponseList.evcsDetails[i].long
            )
            var freeSlotsList = HCResponseList.evcsDetails.get(i).evseDetails
            mMap.addMarker(
                MarkerOptions().position(HCLocation).title(HCResponseList.evcsDetails[i].evcsId)
                    .snippet(
                        "Free Slots: " + getFreeSlotsCount(freeSlotsList).first.toString() + " / " + getFreeSlotsCount(
                            freeSlotsList
                        ).second.toString()
                    )
            )
        }

    }

    private fun getFreeSlotsCount(freeSlotsList: List<EvseDetails>): Pair<Int, Int> {
        var count = 0
        for (i in freeSlotsList.indices) {
            if (freeSlotsList.get(i).isConnected == true) {
                count++
            }
        }
        return Pair(count, freeSlotsList.size)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val testLoc = LatLng(12.9321, 77.6143)

        googleMap.uiSettings.isZoomControlsEnabled = true
        googleMap.uiSettings.isCompassEnabled = true

        googleMap.setOnMyLocationButtonClickListener(this)
        googleMap.setOnMyLocationClickListener(this)
        enableMyLocation()
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(testLoc, 14f))
        googleMap.setOnMarkerClickListener { marker -> // on marker click we are getting the title of our marker
            // which is clicked and displaying it in a toast message.
            val markerName = marker.title
            for( i in newArrayList.indices){
//                for( j in newArrayList[i].evcsDetails.indices) {
                    Log.d("test1234", "${newArrayList[i].evcsDetails[i].evcsId}  ---> $markerName")
                    if (newArrayList[i].evcsDetails[i].evcsId == markerName){
                        Log.d("test1234", "Matched ${newArrayList[i].evcsDetails[i].evcsId}  ---> $markerName")
                        mMap.moveCamera(
                            CameraUpdateFactory.newLatLngZoom(
                                LatLng(
                                    marker.position.latitude,  marker.position.longitude
                                ), 15f
                            )
                        )
                        iJustWantToScroll(i)
                        break
                    }
//                }

            }



            // TODO if id in existing ids
//            Toast.makeText(
//                this@MapsActivity,
//                "Clicked location is $markerName",
//                Toast.LENGTH_SHORT
//            )
//                .show()
            false
        }
        val x = googleMap.isMyLocationEnabled

//        Log.d("test1234", "$x")

    }

    fun iJustWantToScroll(i: Int) {
//        newRecyclerView.scrollToPosition(i)
        newRecyclerView.smoothScrollToPosition(i)
//        newRecyclerView.layoutManager?.scrollToPosition(i)
        //(newRecyclerView.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(0)
    }

    @SuppressLint("MissingPermission")
    private fun enableMyLocation() {
        if (!::mMap.isInitialized) return
        // [START maps_check_location_permission]
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
        } else {
            // Permission to access the location is missing. Show rationale and request permission
            requestPermission(
                this, LOCATION_PERMISSION_REQUEST_CODE,
                Manifest.permission.ACCESS_FINE_LOCATION, true
            )
        }
        // [END maps_check_location_permission]
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        if (requestCode != LOCATION_PERMISSION_REQUEST_CODE) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            return
        }
        if (isPermissionGranted(
                permissions,
                grantResults,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        ) {
            // Enable the my location layer if the permission has been granted.
            enableMyLocation()
        } else {
            // Permission was denied. Display an error message
            // [START_EXCLUDE]
            // Display the missing permission error dialog when the fragments resume.
            permissionDenied = true
            // [END_EXCLUDE]
        }
    }

    // [END maps_check_location_permission_result]
    override fun onResumeFragments() {
        super.onResumeFragments()
        if (permissionDenied) {
            // Permission was not granted, display error dialog.
            showMissingPermissionError()
            permissionDenied = false
        }
    }

    /**
     * Displays a dialog with error message explaining that the location permission is missing.
     */
    private fun showMissingPermissionError() {
        newInstance(true).show(supportFragmentManager, "dialog")
    }

    companion object {
        /**
         * Request code for location permission request.
         *
         * @see .onRequestPermissionsResult
         */
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
    }

    override fun onMyLocationButtonClick(): Boolean {
//        Toast.makeText(this, "MyLocation button clicked", Toast.LENGTH_SHORT)
//            .show()
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(TEST_LAT, TEST_LONG), 15f))
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).
        return false
    }

    override fun onMyLocationClick(location: Location) {
//        Toast.makeText(this, "Current location:\n$location", Toast.LENGTH_LONG).show()
    }
}