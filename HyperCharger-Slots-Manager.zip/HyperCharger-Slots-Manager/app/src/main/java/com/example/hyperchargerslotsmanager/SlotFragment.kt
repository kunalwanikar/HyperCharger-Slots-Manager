package com.example.hyperchargerslotsmanager

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.app.TimePickerDialog
import android.app.TimePickerDialog.OnTimeSetListener
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import com.example.hyperchargerslotsmanager.helpers.BookSlotHelper
import com.example.hyperchargerslotsmanager.helpers.BookSlotHelper.getInstance
import com.example.hyperchargerslotsmanager.model.ConfirmSlotRequest
import com.example.hyperchargerslotsmanager.model.HCFreeSlotResponse
import com.example.hyperchargerslotsmanager.services.BookSlotService
import com.example.hyperchargerslotsmanager.services.ConfirmSlotService
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.squareup.okhttp.OkHttpClient
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [SlotFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class SlotFragment : BottomSheetDialogFragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var dateSetListener: OnDateSetListener? = null
    private var timeSetListener: OnTimeSetListener? = null
    private var date: TextView? = null
    private var time: TextView? = null
    private var evcsId: TextView? = null
    private var landmark:TextView?= null

    private var radiogrp: RadioGroup? = null
    private var radiobtn: RadioButton?= null
//    private var dur1: RadioButton? = null
    private var completeDate :String = ""
    private var completeTime: String = ""
    private var finalDate: String = "1980-12-31"
    private var finalTime: String = "23:59:59"

    private var confirmSlot: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        val root = inflater.inflate(R.layout.fragment_slot, container, false)
        date = root.findViewById(R.id.in_from_date)
        time = root.findViewById(R.id.in_from_time)
        evcsId = root.findViewById(R.id.evcsId)
        landmark = root.findViewById(R.id.fillLandmark)
        radiogrp = root.findViewById(R.id.durationRadioGroup)
        confirmSlot = root.findViewById(R.id.confirmslot)

        var data = arguments?.getParcelable<HCFreeSlotResponse>("key")
        val position = arguments?.getInt("position")

//        Log.d("data1234","$data")

        evcsId?.text = "BOOK SLOT FOR : "+data?.evcsDetails?.get(position!!)?.evcsId!!
        landmark?.text = data?.evcsDetails?.get(position!!)?.landmark


//        kotlin.run {
//            confirmSlot?.isEnabled = !(!TextUtils.isEmpty(date?.text) || !TextUtils.isEmpty(time?.text))
//        }

        confirmSlot?.setOnClickListener(View.OnClickListener {
            Toast.makeText(
                requireContext().applicationContext,
                "Confirm Slot clicked!",
                Toast.LENGTH_SHORT
            ).show()

            val dateString = "$finalDate $finalTime"
            val format = "yyyy-MM-dd HH:mm:ss"
            val milliseconds = dateStringToMilliseconds(dateString, format)

            if(milliseconds<=System.currentTimeMillis()){
                Toast.makeText(
                    requireContext().applicationContext,
                    "Wrong time selected. Re-Enter Date and Time",
                    Toast.LENGTH_SHORT
                ).show()
            }

            val confirmSlotRequest = ConfirmSlotRequest(
                System.currentTimeMillis(),
                data?.evcsDetails?.get(position!!)?.evcsId!!,
                "gun 1",
                "R1GTESTZZZZZ00014",
                milliseconds,
                milliseconds + calculateFinalTime(radiobtn?.text.toString())
            )
//            confirmSlotRequest.timestamp = System.currentTimeMillis()
//            confirmSlotRequest?.fromTimestamp = milliseconds
//            confirmSlotRequest?.vin = "R1GTESTZZZZZ00014"
            val selectedId = radiogrp?.checkedRadioButtonId
            radiobtn = root.findViewById(selectedId!!)

//            confirmSlotRequest?.toTimestamp = milliseconds + calculateFinalTime(radiobtn?.text.toString())
//            confirmSlotRequest?.evcsId = data?.evcsDetails?.get(position!!)?.evcsId!!

            var unfilledSlots: ArrayList<String> = ArrayList()

            for( i in data?.evcsDetails?.get(position!!)?.evseDetails!!){
                if(!i.isConnected){
                    unfilledSlots.add(i.evseId)
                }
            }
//            if(unfilledSlots.size > 0){
//                confirmSlotRequest?.evseId = unfilledSlots[0]
//            }
//            else{
//                confirmSlotRequest?.evseId = "Fill By Yourself"
//            }
//            confirmSlotRequest?.evseId = "GUNSLOT 1"
            Log.d("dubai1234","Request confirmSlotRequest -> $confirmSlotRequest")

            val bookSlotsApi = BookSlotHelper.postInstance().create(ConfirmSlotService::class.java)
            GlobalScope.launch {

                val result = confirmSlotRequest?.let { it1 -> bookSlotsApi.confirmSlot(it1) }
                if (result != null){
                    Log.d("dubai1234", result.isSuccessful.toString())
                }
                else{
                    Log.d("dubai1234","Result is NULL")
                }
            }

//            GlobalScope.launch {
//
//                val result = confirmSlotRequest?.let { it1 -> bookSlotsApi.getHCFreeSlots() }
//                if (result != null)
//                // Checking the results
//                    Log.d("freeslots: ", result.body().toString())
//            }

        })

        date?.setOnClickListener(View.OnClickListener {
            val cal = Calendar.getInstance()
            val year = cal[Calendar.YEAR]
            val month = cal[Calendar.MONTH]
            val day = cal[Calendar.DAY_OF_MONTH]
            val dialog = DatePickerDialog(
                requireContext(),
                android.R.style.Theme_DeviceDefault_Dialog,
                dateSetListener,
                year,
                month,
                day
            )
            dialog.show()
        })

        time?.setOnClickListener(View.OnClickListener {
            val cal = Calendar.getInstance()
            val hour = cal[Calendar.YEAR]
            val minute = cal[Calendar.MONTH]
            val dialog = TimePickerDialog(
                context,
                android.R.style.Theme_DeviceDefault_Dialog,
                timeSetListener,
                hour,
                minute,
                false
            )
            dialog.show()
        })


        dateSetListener =
            OnDateSetListener { view, year, month, dayOfMonth ->
                var month = month
                month += 1
                if(dayOfMonth<=9 && month<=9){
                    completeDate = "0$dayOfMonth/0$month/$year"
                    finalDate = "$year-0$month-0$dayOfMonth"
                }
                else if(month <=9){
                    completeDate = "$dayOfMonth/0$month/$year"
                    finalDate = "$year-0$month-$dayOfMonth"
                }
                else if(dayOfMonth <=9){
                    completeDate = "0$dayOfMonth/$month/$year"
                    finalDate = "$year-$month-0$dayOfMonth"
                }
                else{
                    completeDate = "$dayOfMonth/$month/$year"
                    finalDate = "$year-$month-$dayOfMonth"
                }
                date?.text = completeDate
            }

        timeSetListener = OnTimeSetListener { view, hourOfDay, minute ->
            if( minute <= 9){
                completeTime = "$hourOfDay:0${minute} in 24hrs Format"
                finalTime = "$hourOfDay:0$minute:00"
            }
            else{
                completeTime = "$hourOfDay:$minute in 24hrs Format"
                finalTime = "$hourOfDay:0$minute:00"
            }
            time?.text = completeTime
        }
        return root
    }

    fun calculateFinalTime(value: String?) : Long{
        if(value == "15 Min"){
            return 900000
        }
        else if (value == "30 Min"){
            return 30*60000
        }
        else if (value == "45 Min"){
            return 45*60000
        }
        return 60*60000
    }

    fun dateStringToMilliseconds(dateString: String, format: String): Long {
        val sdf = SimpleDateFormat(format)
        val date = sdf.parse(dateString)
        return date.time
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment SlotFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            SlotFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}