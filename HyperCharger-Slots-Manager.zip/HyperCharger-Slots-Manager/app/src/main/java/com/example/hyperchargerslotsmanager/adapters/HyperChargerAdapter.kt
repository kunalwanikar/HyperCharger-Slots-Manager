package com.example.hyperchargerslotsmanager.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.hyperchargerslotsmanager.constants.Constant
import com.example.hyperchargerslotsmanager.R
import com.example.hyperchargerslotsmanager.model.EvseDetails
import com.example.hyperchargerslotsmanager.model.HCFreeSlotResponse
import com.google.android.gms.maps.GoogleMap
import com.google.android.material.imageview.ShapeableImageView
import kotlin.math.*

class HyperChargerAdapter(
    private val slotsList: ArrayList<HCFreeSlotResponse>,
    mContext: Context, val btnlistener: BtnClickListener, val mMap: GoogleMap
) : RecyclerView.Adapter<HyperChargerAdapter.ListOfHCSlotsHolder>() {
    companion object {
        var mClickListener: BtnClickListener? = null
    }

    lateinit var mContext: Context

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListOfHCSlotsHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_hypercharger_card, parent, false)
        mContext = parent.context
        return ListOfHCSlotsHolder(itemView)
    }

    override fun onBindViewHolder(holder: ListOfHCSlotsHolder, position: Int) {
        mClickListener = btnlistener

        val currentItem = slotsList[position]
//       / glide
        // holder.titleImage.setImageResource(currentItem.evcsDetails.get(position).pic)
        val media = currentItem.evcsDetails.get(position).pic
        Glide.with(mContext)
            .load(media)
            .into(holder.titleImage)

//        holder.titleImage.load(currentItem.evcsDetails[position].pic){
//            crossfade(true)
//            placeholder(R.drawable.a)
//            transformations(CircleCropTransformation())
//        }
        holder.heading.text = "Hypercharger ID : " + currentItem.evcsDetails.get(position).evcsId


        holder.itemView.setOnClickListener(View.OnClickListener {
            mClickListener?.onImageClick(currentItem,position)
        })

        val distanceToHC = chatGptDistanceCode(
            Constant.TEST_LAT,
            Constant.TEST_LONG,
            currentItem.evcsDetails.get(position).lat,
            currentItem.evcsDetails.get(position).long
        )
        holder.distance.text = distanceToHC

        var freeSlotsList = currentItem.evcsDetails.get(position).evseDetails

        holder.bookSlot.setOnClickListener {
            mClickListener?.onBtnClick(currentItem,position)

//            TODO : Call Confirm Slot Page
//            bookSlot()
//            val confirmSlotResponse: ConfirmSlotResponse =
//            if(confirmSlotResponse){
//                Toast.makeText(mContext,"Your Slot is Confirmed", Toast.LENGTH_SHORT).show()
//            }
//            else{
//                Toast.makeText(mContext,"Sorry we couldn't process the slot timings", Toast.LENGTH_SHORT).show()
//            }
//            val fragmentTransaction = supportFragmentManager.beginTransaction()
//            val newFragment = MyNewFragment()
//            fragmentTransaction.add(R.id., newFragment)
//            fragmentTransaction.addToBackStack(null)
//            fragmentTransaction.commit()

        }

        holder.freeSlots.text =
            "Free Slots : " + getFreeSlotsCount(freeSlotsList).first + " / " + getFreeSlotsCount(
                freeSlotsList
            ).second
    }

//    private fun bookSlot(){
//        val bookSlotService = BookSlotHelper.getInstance().create(BookSlotService::class.java)
//        Log.d("abcd1234", "Result Start :::::::::::::::::::::::::::::::::::: Result End")
//        // launching a new coroutine
//
//        GlobalScope.launch {
//
//                Log.d("abcd1234", "Before Result :::::::::::::::::::::::::::::::::::: Result End")
////            Log.d("abcd1234", lbsService.getHCFreeSlots().body().toString())
//                val res = bookSlotService.getHCFreeSlots()
//                val confirmSlotRequest: ConfirmSlotRequest = getFreeSlots(res.body())
//                val result = bookSlotService.confirmSlot(confirmSlotRequest)
//                Log.d("abcd1234", "Result ::::: ${result.code()}")
//                ///  if (result != null)
//                // Checking the results
//                Log.d("abcd1234", result.body().toString())
//                result.body()?.let {
//                    run {
//
//                    }
//                }
//
//        }
//    }
//
//    fun getFreeSlots(HCResponseList: HCFreeSlotResponse):ConfirmSlotRequest?{
//        val confirmSlotRequest: ConfirmSlotRequest?= null
//        return confirmSlotRequest
//    }


    fun chatGptDistanceCode(lat1: Double, lon1: Double, lat2: Double, lon2: Double): String {
        val earthRadius = 6371.0 // Radius of the earth in km
        val dLat = deg2rad(lat2 - lat1)
        val dLon = deg2rad(lon2 - lon1)
        val a =
            sin(dLat / 2) * sin(dLat / 2) + cos(deg2rad(lat1)) * cos(deg2rad(lat2)) * sin(dLon / 2) * sin(
                dLon / 2
            )
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (earthRadius * c).toString().formatDistance() // returns the distance in km
    }

//    fun calculateDistanceFromCurrentLocation(
//        currentLat: Double,
//        currentLong: Double,
//        destinationLatitude: Double,
//        destinationLongitude: Double
//    ): String {
//        val theta = currentLong - destinationLongitude
//        var dist = (
//                sin(deg2rad(currentLat)) *
//                        sin(deg2rad(destinationLatitude)) +
//                        (
//                                cos(deg2rad(currentLat)) *
//                                        cos(deg2rad(destinationLatitude)) *
//                                        cos(deg2rad(theta))
//                                )
//                )
//        dist = acos(dist)
//        dist = rad2deg(dist)
//        dist *= 60 * 1.1515
//        return (dist / 1000000).toString().formatDistance()
//    }

    private fun deg2rad(deg: Double): Double {
        return deg * Math.PI / 180.0
    }

    private fun rad2deg(rad: Double): Double {
        return rad * 180.0 / Math.PI
    }

    private fun String.formatDistance(): String {
        if (this.split(' ').size == 1) {
            return this.substring(0, 4) + " km"
        } else if (this.split(' ').last()[0] != 'm') {
            return this.split(' ')[0] + " km"
        }
        return this
    }

    private fun getFreeSlotsCount(freeSlotsList: List<EvseDetails>): Pair<Int, Int> {
        var count = 0
        for (i in freeSlotsList.indices) {
            if (freeSlotsList.get(i).isConnected == true) {
                count++
            }
        }
        return Pair(count, freeSlotsList.size)
    }

    override fun getItemCount(): Int {
        return slotsList.size
    }


    class ListOfHCSlotsHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleImage: ShapeableImageView = itemView.findViewById(R.id.title_image)
        val heading: TextView = itemView.findViewById(R.id.tvHeading)
        val distance: TextView = itemView.findViewById(R.id.distanceToHC)
        val freeSlots: TextView = itemView.findViewById(R.id.freeSlots)
        val bookSlot: Button = itemView.findViewById(R.id.bookslot)
    }


    open interface BtnClickListener {
        fun onBtnClick(currentItem: HCFreeSlotResponse, position: Int)
        fun onImageClick(hcList: HCFreeSlotResponse, position: Int)
    }
}