package com.example.hyperchargerslotsmanager.constants

class Constant {
    companion object{
        const val TEST_LAT = 12.9344
        const val TEST_LONG = 77.6111
    }
}