package com.example.hyperchargerslotsmanager.model

import com.google.gson.annotations.SerializedName

data class ConfirmSlotRequest(
    @SerializedName("timestamp")
    var timestamp: Long,
    @SerializedName("evcsId")
    var evcsId: String,
    @SerializedName("evseId")
    var evseId: String,
    @SerializedName("vin")
    var vin: String,
    @SerializedName("fromTimestamp")
    var fromTimestamp: Long,
    @SerializedName("toTimestamp")
    var toTimestamp: Long,
)
