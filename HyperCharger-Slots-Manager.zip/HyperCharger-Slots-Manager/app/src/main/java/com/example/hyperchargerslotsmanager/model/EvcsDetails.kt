package com.example.hyperchargerslotsmanager.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

data class EvcsDetails(
    @SerializedName("evcsId")
    val evcsId: String,
    @SerializedName("lat")
    val lat: Double,
    @SerializedName("long")
    val long: Double,
    @SerializedName("landmark")
    val landmark: String,
    @SerializedName("pic")
    val pic: String,
    @SerializedName("evseDetails")
    val evseDetails: List<EvseDetails>
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString()!!,
        parcel.readDouble(),
        parcel.readDouble(),
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readArrayList(EvseDetails::class.java.classLoader) as List<EvseDetails>
    ) {
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.writeString(evcsId)
        dest?.writeDouble(lat)
        dest?.writeDouble(long)
        dest?.writeString(landmark)
        dest?.writeString(pic)
        dest?.writeList(evseDetails)
    }

    companion object CREATOR : Parcelable.Creator<EvcsDetails> {
        override fun createFromParcel(parcel: Parcel): EvcsDetails {
            return EvcsDetails(parcel)
        }

        override fun newArray(size: Int): Array<EvcsDetails?> {
            return arrayOfNulls(size)
        }
    }
}
