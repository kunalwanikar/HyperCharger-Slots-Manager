package com.example.hyperchargerslotsmanager.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

data class EvseDetails(
    @SerializedName("evseId")
    val evseId: String,
    @SerializedName("isConnected")
    val isConnected: Boolean,
    @SerializedName("vin")
    val vin: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString()!!,
        parcel.readByte() != 0.toByte(),
        parcel.readString()!!
    ) {
    }

    override fun describeContents(): Int {
        return 0;
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.readString()
        dest?.readByte()
        dest?.readString()
    }

    companion object CREATOR : Parcelable.Creator<EvseDetails> {
        override fun createFromParcel(parcel: Parcel): EvseDetails {
            return EvseDetails(parcel)
        }

        override fun newArray(size: Int): Array<EvseDetails?> {
            return arrayOfNulls(size)
        }
    }
}
