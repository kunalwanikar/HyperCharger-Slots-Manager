package com.example.hyperchargerslotsmanager.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

data class HCFreeSlotResponse(
    @SerializedName("timestamp")
    val timestamp: Long,
    @SerializedName("evcsDetails")
    val evcsDetails: List<EvcsDetails>
) : Parcelable {
    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.writeLong(timestamp)
        dest?.writeList(evcsDetails)
    }

    companion object CREATOR : Parcelable.Creator<HCFreeSlotResponse> {
        override fun createFromParcel(parcel: Parcel): HCFreeSlotResponse {
            return HCFreeSlotResponse(
                parcel.readLong()!!,
                parcel.readArrayList(EvcsDetails::class.java.classLoader) as List<EvcsDetails>
            )
        }

        override fun newArray(size: Int): Array<HCFreeSlotResponse?> {
            return arrayOfNulls(size)
        }
    }
}

