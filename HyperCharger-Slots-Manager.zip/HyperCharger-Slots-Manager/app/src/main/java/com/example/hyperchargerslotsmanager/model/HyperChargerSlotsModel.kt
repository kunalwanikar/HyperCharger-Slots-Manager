package com.example.hyperchargerslotsmanager.model

data class HyperChargerSlotsModel(
    var titleImage: Int,
    var heading: String,
    var distance: String,
    var freeSlots: String
)
