package com.example.hyperchargerslotsmanager.services

import com.example.hyperchargerslotsmanager.model.ConfirmSlotRequest
import com.example.hyperchargerslotsmanager.model.HCFreeSlotResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Url

interface BookSlotService {
    @GET("/0f6f2c1fc933e884363d")
    suspend fun getHCFreeSlots(): Response<HCFreeSlotResponse>

}