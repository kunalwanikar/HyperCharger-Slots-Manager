package com.example.hyperchargerslotsmanager.services

import com.example.hyperchargerslotsmanager.model.ConfirmSlotRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface ConfirmSlotService {
    @POST("/hypercharger")
    suspend fun confirmSlot(@Body body: ConfirmSlotRequest): Response<ConfirmSlotRequest>
}