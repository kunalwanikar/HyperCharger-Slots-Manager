package com.example.hyperchargerslotsmanager.utils

sealed class Failure(
    val handleActionType: HandleActionType,
    override val errorMessage: String,
    val errorCode: String? = null,
) :
    Throwable(errorMessage), IFailure {

    val priorityLevel = handleActionType.priority.level


    abstract class FeatureFailure(
        handleActionType: HandleActionType,
        errorMessage: String,
        errorCode: String?,
    ) :
        Failure(handleActionType, errorMessage, errorCode)
}

sealed class HandleActionType(val priority: Priority) {
    object Retry : HandleActionType(
        Priority.MEDIUM
    )

    data class RequestPermission(val permissions: List<String>) :
        HandleActionType(Priority.HIGHEST)

    data class GoToSettings(val settingsTarget: SettingsTarget) : HandleActionType(
        Priority.HIGHEST
    )

    object ContactEtergo : HandleActionType(
        Priority.HIGH
    )

    object Ignore : HandleActionType(
        Priority.LOWEST
    )

    object Message : HandleActionType(
        Priority.LOW
    ) // TODO: Pass message as argument
}

enum class Priority(val level: Int) {
    HIGHEST(500), HIGH(400), MEDIUM(300), LOW(200), LOWEST(100)
}

enum class SettingsTarget {
    STORAGE, NETWORK, LOCATION
}

sealed class HttpErrors(errorMessage: String) :
    Failure.FeatureFailure(HandleActionType.Retry, errorMessage, null) {

    class Network(errorMessage: String) : HttpErrors(errorMessage)
    class Other(errorMessage: String) : HttpErrors(errorMessage)
    class Timeout(errorMessage: String) : HttpErrors(errorMessage)
    class Unknown(errorMessage: String) : HttpErrors(errorMessage)
}

