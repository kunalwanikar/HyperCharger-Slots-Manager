package com.example.hyperchargerslotsmanager.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException
import java.net.SocketTimeoutException

suspend inline fun <T, X : Any> safeApiCall(
    crossinline apiCall: suspend () -> T,
    successTransform: (T) -> X,
): Either<HttpErrors, X> {
    return try {
        val response = withContext(Dispatchers.IO) { apiCall.invoke() }
        Either.Success(successTransform(response))
    } catch (e: Exception) {
        e.printStackTrace()
        return when (e) {
            is HttpException -> {
                Either.Error(HttpErrors.Other(e.localizedMessage ?: "Something went wrong"))
            }
            is SocketTimeoutException -> Either.Error(
                HttpErrors.Timeout(
                    e.localizedMessage
                        ?: "Something went wrong"
                )
            )
            is IOException -> Either.Error(
                HttpErrors.Network(
                    e.localizedMessage
                        ?: "Something went wrong"
                )
            )
            else -> Either.Error(HttpErrors.Unknown(e.localizedMessage ?: "Something went wrong"))
        }
    }
}