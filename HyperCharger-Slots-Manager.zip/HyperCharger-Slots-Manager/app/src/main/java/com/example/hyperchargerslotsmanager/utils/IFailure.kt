package com.example.hyperchargerslotsmanager.utils

interface IFailure {
    val errorMessage: String
}